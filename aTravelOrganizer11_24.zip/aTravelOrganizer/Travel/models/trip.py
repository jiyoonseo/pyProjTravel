﻿class Trip(object):
    def __init__(self, trip_id, trip_name, user_id):
        self.trip_id = trip_id        
        self.trip_name = trip_name
        self.user_id = user_id


    """description of class"""


